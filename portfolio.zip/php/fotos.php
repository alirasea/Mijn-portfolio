<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/fotos.css">
    <title>Mijn Werk</title>
</head>
<body>
    <div id="container">
       
    <div id="container2"><img src="../img/img2/1.jpg" alt=""></div>
    <div id="container2"><img src="../img/img2/2.jpg" alt=""></div>


   
    <div id="container2"><img src="../img/img2/3.jpg" alt=""></div>
    <div id="container2"><img src="../img/img2/4.jpg" alt=""></div>
    
      
    <div id="container2"><img src="../img/img2/5.jpg" alt=""></div>
    <div id="container2"><img src="../img/img2/6.jpg" alt=""></div>

       
    <div id="container2"><img src="../img/img2/7.jpg" alt=""></div>
    <div id="container2"><img src="../img/img2/8.jpg" alt=""></div>

    
        
    </div>
    
</body>
</html>